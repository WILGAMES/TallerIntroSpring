package co.icesi.taller_intro.servlet;


import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

@WebServlet("/track")
public class TrackServlet extends HttpServlet {


}
