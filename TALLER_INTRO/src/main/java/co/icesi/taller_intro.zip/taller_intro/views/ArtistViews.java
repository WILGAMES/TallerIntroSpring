package co.icesi.taller_intro.views;

import co.icesi.taller_intro.model.Artist;

import java.util.List;

public class ArtistViews {

    public String listArtist(List<Artist> artists) {


    return null;
    }
}
